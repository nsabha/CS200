#include <iostream>
#include <string>
#include <vector>
#include "User.h"

void main()
{
	User u("tech");

	cout << u.GetUsername();

}